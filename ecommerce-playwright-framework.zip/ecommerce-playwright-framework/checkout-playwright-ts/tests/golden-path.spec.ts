import { expect, test } from '@playwright/test';
import { CheckoutPage } from '../pages/CheckoutPage';

test.describe('Golden Path', () => {
  test('cart logic updates totals dynamically and guest checkout succeeds', async ({ page }) => {
    await page.route('**/api/checkout', async (route) => {
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, orderId: 'ORD-E2E-1001' })
      });
    });

    const checkout = new CheckoutPage(page);
    await checkout.goto();

    await checkout.addProductByName('Premium Widget', 2);
    await checkout.addProductByName('Mega Widget', 1);

    await expect(checkout.cartLine('Premium Widget')).toContainText('x2');
    await expect(checkout.cartLine('Mega Widget')).toContainText('x1');

    await expect(checkout.subtotal()).toHaveText(checkout.currencyAmount('$', 400));
    await expect(checkout.tax()).toHaveText(checkout.currencyAmount('$', 32));
    await expect(checkout.total()).toHaveText(checkout.currencyAmount('$', 432));

    await checkout.checkoutButton.click();

    await expect(checkout.statusMessage).toContainText('Success! Order ID: ORD-E2E-1001');
    await expect(checkout.emptyCartMessage).toBeVisible();
  });

  test.fail('search and filter should narrow to matching products', async ({ page }) => {
    const checkout = new CheckoutPage(page);
    await checkout.goto();

    await expect(page.getByRole('searchbox', { name: /search/i })).toBeVisible();
    await page.getByRole('searchbox', { name: /search/i }).fill('Widget');

    await expect(page.getByRole('button', { name: /filter/i })).toBeVisible();
    await page.getByRole('button', { name: /filter/i }).click();

    await expect(page.getByText('Premium Widget')).toBeVisible();
  });
});
