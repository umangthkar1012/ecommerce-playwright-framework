import { expect, test } from '@playwright/test';
import { CheckoutPage } from '../pages/CheckoutPage';

test.describe('Payment Failure & Visual Stability', () => {
  test('handles payment failure via API interception', async ({ page }) => {
    await page.route('**/api/checkout', async (route) => {
      await route.fulfill({
        status: 400,
        contentType: 'application/json',
        body: JSON.stringify({ success: false, message: 'Payment Processor Error' })
      });
    });

    const checkout = new CheckoutPage(page);
    await checkout.goto();
    await checkout.addProductByName('Super Widget', 1);

    await checkout.checkoutButton.click();

    await expect(checkout.statusMessage).toContainText('Error: Payment Processor Error');
    await expect(checkout.checkoutButton).toBeEnabled();
  });

  test('checkout button remains visually stable in loading state', async ({ page }) => {
    let releaseCheckoutResponse: (() => void) | undefined;
    const pendingResponse = new Promise<void>((resolve) => {
      releaseCheckoutResponse = resolve;
    });

    await page.route('**/api/checkout', async (route) => {
      await pendingResponse;
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ success: true, orderId: 'ORD-VISUAL-2002' })
      });
    });

    const checkout = new CheckoutPage(page);
    await checkout.goto();
    await checkout.addProductByName('Premium Widget', 1);

    const before = await checkout.checkoutButton.boundingBox();
    if (!before) {
      throw new Error('Checkout button was not visible before loading-state visual check.');
    }

    const clickPromise = checkout.checkoutButton.click();
    await expect(checkout.checkoutButton).toHaveClass(/loading/);

    await expect(checkout.checkoutButton).toHaveScreenshot('checkout-button-loading.png');

    const during = await checkout.checkoutButton.boundingBox();
    if (!during) {
      throw new Error('Checkout button was not visible during loading-state visual check.');
    }

    expect(Math.abs(before.x - during.x)).toBeLessThan(1);
    expect(Math.abs(before.width - during.width)).toBeLessThan(1);

    if (!releaseCheckoutResponse) {
      throw new Error('Payment response release callback was not initialized.');
    }

    releaseCheckoutResponse();
    await clickPromise;

    await expect(checkout.statusMessage).toContainText('Success! Order ID: ORD-VISUAL-2002');
  });
});
