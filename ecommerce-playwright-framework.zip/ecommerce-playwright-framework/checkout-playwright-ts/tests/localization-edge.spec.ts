import { expect, test } from '@playwright/test';
import { CheckoutPage } from '../pages/CheckoutPage';

test.describe('Localization & Edge Cases', () => {
  test('currency conversion updates prices and totals from USD to EUR', async ({ page }) => {
    const checkout = new CheckoutPage(page);
    await checkout.goto();

    await expect(checkout.productCard('Premium Widget').locator('.price')).toHaveText(checkout.currencyAmount('$', 100));

    await checkout.addProductByName('Premium Widget', 1);
    await expect(checkout.subtotal()).toHaveText(checkout.currencyAmount('$', 100));

    await checkout.switchCurrency('EUR');

    await expect(checkout.productCard('Premium Widget').locator('.price')).toHaveText(checkout.currencyAmount('€', 92));
    await expect(checkout.subtotal()).toHaveText(checkout.currencyAmount('€', 92));
    await expect(checkout.tax()).toHaveText(checkout.currencyAmount('€', 7.36));
    await expect(checkout.total()).toHaveText(checkout.currencyAmount('€', 99.36));
  });

  test.fail('adding more units than stock should show a friendly inventory error', async ({ page }) => {
    const checkout = new CheckoutPage(page);
    await checkout.goto();

    await checkout.addProductByName('Premium Widget', 6);

    await expect(page.getByText(/only 5 left in stock/i)).toBeVisible();
  });

  test.fail('mobile viewport should expose filter drawer behavior under 768px', async ({ page }) => {
    await page.setViewportSize({ width: 375, height: 800 });

    const checkout = new CheckoutPage(page);
    await checkout.goto();

    const filterButton = page.getByRole('button', { name: /filter/i });
    await expect(filterButton).toBeVisible();
    await filterButton.click();

    await expect(page.getByRole('complementary', { name: /filters/i })).toBeVisible();
  });
});
