# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: golden-path.spec.ts >> Golden Path >> search and filter should narrow to matching products
- Location: tests\golden-path.spec.ts:33:8

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('searchbox', { name: /search/i })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('searchbox', { name: /search/i })

```

```yaml
- banner:
  - heading "BluNav Checkout" [level=1]
  - combobox "Select Currency":
    - option "USD ($)" [selected]
    - option "EUR (€)"
    - option "GBP (£)"
- main:
  - heading "Premium Widget" [level=3]
  - paragraph: $100.00
  - button "Add to Cart"
  - heading "Super Widget" [level=3]
  - paragraph: $150.00
  - button "Add to Cart"
  - heading "Mega Widget" [level=3]
  - paragraph: $200.00
  - button "Add to Cart"
- complementary:
  - heading "Order Summary" [level=2]
  - paragraph: Your cart is empty.
  - text: Subtotal $0.00 Tax (8%) $0.00 Total $0.00
  - checkbox "Simulate Payment Failure"
  - text: Simulate Payment Failure
  - button "Proceed to Checkout" [disabled]
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import { CheckoutPage } from '../pages/CheckoutPage';
  3  | 
  4  | test.describe('Golden Path', () => {
  5  |   test('cart logic updates totals dynamically and guest checkout succeeds', async ({ page }) => {
  6  |     await page.route('**/api/checkout', async (route) => {
  7  |       await route.fulfill({
  8  |         status: 200,
  9  |         contentType: 'application/json',
  10 |         body: JSON.stringify({ success: true, orderId: 'ORD-E2E-1001' })
  11 |       });
  12 |     });
  13 | 
  14 |     const checkout = new CheckoutPage(page);
  15 |     await checkout.goto();
  16 | 
  17 |     await checkout.addProductByName('Premium Widget', 2);
  18 |     await checkout.addProductByName('Mega Widget', 1);
  19 | 
  20 |     await expect(checkout.cartLine('Premium Widget')).toContainText('x2');
  21 |     await expect(checkout.cartLine('Mega Widget')).toContainText('x1');
  22 | 
  23 |     await expect(checkout.subtotal()).toHaveText(checkout.currencyAmount('$', 400));
  24 |     await expect(checkout.tax()).toHaveText(checkout.currencyAmount('$', 32));
  25 |     await expect(checkout.total()).toHaveText(checkout.currencyAmount('$', 432));
  26 | 
  27 |     await checkout.checkoutButton.click();
  28 | 
  29 |     await expect(checkout.statusMessage).toContainText('Success! Order ID: ORD-E2E-1001');
  30 |     await expect(checkout.emptyCartMessage).toBeVisible();
  31 |   });
  32 | 
  33 |   test.fail('search and filter should narrow to matching products', async ({ page }) => {
  34 |     const checkout = new CheckoutPage(page);
  35 |     await checkout.goto();
  36 | 
> 37 |     await expect(page.getByRole('searchbox', { name: /search/i })).toBeVisible();
     |                                                                    ^ Error: expect(locator).toBeVisible() failed
  38 |     await page.getByRole('searchbox', { name: /search/i }).fill('Widget');
  39 | 
  40 |     await expect(page.getByRole('button', { name: /filter/i })).toBeVisible();
  41 |     await page.getByRole('button', { name: /filter/i }).click();
  42 | 
  43 |     await expect(page.getByText('Premium Widget')).toBeVisible();
  44 |   });
  45 | });
  46 | 
```