# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: localization-edge.spec.ts >> Localization & Edge Cases >> mobile viewport should expose filter drawer behavior under 768px
- Location: tests\localization-edge.spec.ts:31:8

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('button', { name: /filter/i })
Expected: visible
Timeout: 10000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 10000ms
  - waiting for getByRole('button', { name: /filter/i })

```

```yaml
- banner:
  - heading "BluNav Checkout" [level=1]
  - combobox "Select Currency":
    - option "USD ($)" [selected]
    - option "EUR (€)"
    - option "GBP (£)"
- main:
  - heading "Premium Widget" [level=3]
  - paragraph: $100.00
  - button "Add to Cart"
  - heading "Super Widget" [level=3]
  - paragraph: $150.00
  - button "Add to Cart"
  - heading "Mega Widget" [level=3]
  - paragraph: $200.00
  - button "Add to Cart"
- complementary:
  - heading "Order Summary" [level=2]
  - paragraph: Your cart is empty.
  - text: Subtotal $0.00 Tax (8%) $0.00 Total $0.00
  - checkbox "Simulate Payment Failure"
  - text: Simulate Payment Failure
  - button "Proceed to Checkout" [disabled]
```

# Test source

```ts
  1  | import { expect, test } from '@playwright/test';
  2  | import { CheckoutPage } from '../pages/CheckoutPage';
  3  | 
  4  | test.describe('Localization & Edge Cases', () => {
  5  |   test('currency conversion updates prices and totals from USD to EUR', async ({ page }) => {
  6  |     const checkout = new CheckoutPage(page);
  7  |     await checkout.goto();
  8  | 
  9  |     await expect(checkout.productCard('Premium Widget').locator('.price')).toHaveText(checkout.currencyAmount('$', 100));
  10 | 
  11 |     await checkout.addProductByName('Premium Widget', 1);
  12 |     await expect(checkout.subtotal()).toHaveText(checkout.currencyAmount('$', 100));
  13 | 
  14 |     await checkout.switchCurrency('EUR');
  15 | 
  16 |     await expect(checkout.productCard('Premium Widget').locator('.price')).toHaveText(checkout.currencyAmount('€', 92));
  17 |     await expect(checkout.subtotal()).toHaveText(checkout.currencyAmount('€', 92));
  18 |     await expect(checkout.tax()).toHaveText(checkout.currencyAmount('€', 7.36));
  19 |     await expect(checkout.total()).toHaveText(checkout.currencyAmount('€', 99.36));
  20 |   });
  21 | 
  22 |   test.fail('adding more units than stock should show a friendly inventory error', async ({ page }) => {
  23 |     const checkout = new CheckoutPage(page);
  24 |     await checkout.goto();
  25 | 
  26 |     await checkout.addProductByName('Premium Widget', 6);
  27 | 
  28 |     await expect(page.getByText(/only 5 left in stock/i)).toBeVisible();
  29 |   });
  30 | 
  31 |   test.fail('mobile viewport should expose filter drawer behavior under 768px', async ({ page }) => {
  32 |     await page.setViewportSize({ width: 375, height: 800 });
  33 | 
  34 |     const checkout = new CheckoutPage(page);
  35 |     await checkout.goto();
  36 | 
  37 |     const filterButton = page.getByRole('button', { name: /filter/i });
> 38 |     await expect(filterButton).toBeVisible();
     |                                ^ Error: expect(locator).toBeVisible() failed
  39 |     await filterButton.click();
  40 | 
  41 |     await expect(page.getByRole('complementary', { name: /filters/i })).toBeVisible();
  42 |   });
  43 | });
  44 | 
```