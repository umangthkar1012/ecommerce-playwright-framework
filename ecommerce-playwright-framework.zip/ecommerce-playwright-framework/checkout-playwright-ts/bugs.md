# Bug Report

## 1) Search & Filter Controls Missing (High)
- Requirement says users should be able to search and filter products.
- Current UI does not provide a search input or filter controls.
- Impact: users cannot narrow product catalogs by brand or price range.
- Covered by expected-failure test: `tests/golden-path.spec.ts` (`search and filter should narrow to matching products`).

## 2) Inventory Constraint Not Enforced (High)
- Requirement says adding quantity beyond available stock should show a user-friendly error.
- Current cart logic increments quantity without stock validation or warning.
- Impact: checkout flow can proceed with unrealistic quantities.
- Covered by expected-failure test: `tests/localization-edge.spec.ts` (`adding more units than stock should show a friendly inventory error`).

## 3) Mobile Filter Drawer Flow Missing (Medium)
- Requirement says filters should become a mobile drawer below 768px viewport width.
- Current responsive design collapses grid layout but no filter drawer exists.
- Impact: mobile users have no filtering experience.
- Covered by expected-failure test: `tests/localization-edge.spec.ts` (`mobile viewport should expose filter drawer behavior under 768px`).

## 4) Refresh During Payment Loses Intent (Medium)
- If page is refreshed while checkout is in processing state, cart and checkout state reset.
- Impact: user sees no confirmation path and may duplicate order attempts.
- Recommendation: persist pending checkout status server-side and recover on reload.
