# Checkout Localization E2E (Playwright + TypeScript)

This project contains a maintainable Playwright suite for the QA challenge.

## Coverage
- Golden purchase path (cart updates, tax totals, guest checkout success).
- Currency conversion checks (USD to EUR).
- Payment failure handling through API interception.
- Visual stability check for checkout button loading state.
- Expected-failure tests for currently missing product requirements (search/filter, inventory cap message, mobile filter drawer).

## Commands
- `npm test`: run in headless mode.
- `npm run test:headed`: run with browser UI.
- `npm run test:ui`: Playwright UI mode.
- `npm run report`: open HTML report.

## Notes
- This suite intentionally does not modify `Checkout_app`.
- Tests run the static app from `../Checkout_app/public` and intercept `/api/checkout` when needed.
