import { expect, Locator, Page } from '@playwright/test';

export class CheckoutPage {
  readonly page: Page;
  readonly currencySelector: Locator;
  readonly checkoutButton: Locator;
  readonly statusMessage: Locator;
  readonly emptyCartMessage: Locator;

  constructor(page: Page) {
    this.page = page;
    this.currencySelector = page.getByLabel('Select Currency');
    this.checkoutButton = page.locator('#checkout-btn');
    this.statusMessage = page.locator('#status-container');
    this.emptyCartMessage = page.getByText('Your cart is empty.');
  }

  async goto(): Promise<void> {
    await this.page.goto('/');
    await expect(this.page.getByRole('heading', { name: 'BluNav Checkout' })).toBeVisible();
  }

  async addProductByName(name: string, quantity = 1): Promise<void> {
    const card = this.page.locator('.product-card').filter({ hasText: name });
    const addToCartButton = card.getByRole('button', { name: 'Add to Cart' });

    for (let i = 0; i < quantity; i += 1) {
      await addToCartButton.click();
    }
  }

  async switchCurrency(currency: 'USD' | 'EUR' | 'GBP'): Promise<void> {
    await this.currencySelector.selectOption(currency);
  }

  currencyAmount(symbol: string, amount: number): RegExp {
    return new RegExp(`^\\${symbol}${amount.toFixed(2)}$`);
  }

  productCard(name: string): Locator {
    return this.page.locator('.product-card').filter({ hasText: name });
  }

  cartLine(name: string): Locator {
    return this.page.locator('.cart-item').filter({ hasText: name });
  }

  subtotal(): Locator {
    return this.page.locator('#subtotal');
  }

  tax(): Locator {
    return this.page.locator('#tax-amount');
  }

  total(): Locator {
    return this.page.locator('#total-amount');
  }
}
